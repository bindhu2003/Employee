
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Organization Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="navi-container">
        <div class="orga-name">
            <marquee behavior="scroll" direction="left">NRSC task1</marquee>
        </div>
        <ul class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="form.php">Form</a></li>
            <li><a href="view.php">View</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>WELCOME TO THE ORGANIZATION</h1>
        <p>This is the website for employee data.</p>
    </div>
</body>
</html>
